import sqlite3  #import 
import pandas as pd 

def checking_connection(db_loc):
	#establishing a connection 
	conn = sqlite3.connect(db_loc)
	conn.close()
	return (True)


def executing_command(command, db_loc):
	if checking_connection(db_loc):
		conn = sqlite3.connect(db_loc)
		conn.execute(command)
		conn.commit()
		conn.close()


def create_table_command(table_name, dict_col_and_types):
	command = "CREATE TABLE {} ".format(table_name)
	command += "("
	for col in dict_col_and_types.keys():
		command += str(col) + str(" ")
		command += str(dict_col_and_types[col]) + str(" ,")
	command = command[: -1]
	command += ")"
	command += ";"
	return command


def create_insert_command(table_name, dict_col_and_values):
	command = "INSERT INTO {} ".format(table_name)
	command += " ("
	for col in dict_col_and_values.keys():
		command += str(col) + str(" ,")
	command = command[: -1]
	command += ") "
	command += "VALUES" 
	command += "("	
	for col in dict_col_and_values.keys():
		command += str(dict_col_and_values[col]) + str(" ,")
	command = command[: -1]
	command += ")"
	command += ";"
	return command


def from_csv(db_loc, table_name, dict_col_and_types):
	command = create_table_command(table_name, dict_col_and_types)
	executing_command(command, db_loc)   
	df = pd.read_csv(r"Book3.csv")
	dict_col_and_values = dict_col_and_types
	for x in df.values:
		e = []
		for t in tuple(x):
			if type(t) is str:
				e.append(str('\'') + str(t) + str('\''))
			else:
				e.append(t) 
		i = 0
		for col in dict_col_and_values.keys():
			dict_col_and_values[col] = e[i]
			i += 1 
		command = create_insert_command(table_name, dict_col_and_values)
		executing_command(command, db_loc)


def selecting_data_for_model(db_loc, table_name, dict_col_and_types):
	#first checking the last row ID so we will check whether it is greater than 72 as 
	#we have assumed max_P to be 6 and max_Q to be 2 as 3*2 = 6 years 
	#if it is lesss thand 72 we will take max_P and max_Q to be what ever it is possible
	
	# finding the size of the database
	command = "SELECT ID FROM {} ".format(table_name) 
	command += "ORDER BY ID "
	command += "DESC LIMIT 1 ;"
	conn = sqlite3.connect(db_loc)
	curser = conn.execute(command)
	for row in curser:
		size = row[0]
	conn.close()
	# selecting the max_P and max_Q based on the data 
	if size > 72: 
		max_P = 6 
		max_Q = 2
	elif size <= 72:
		max_P = (size) // 12
		max_Q  = (size) // (3 * 12)

	# the noofrows that we are going to take is max_P * 12 
	noofrows = max_P * 12
	command = "SELECT * FROM {} ".format(table_name) 
	command += "ORDER BY ID "
	command += "DESC LIMIT {} ;".format(noofrows)
	conn = sqlite3.connect(db_loc)
	curser = conn.execute(command)
	data_tuple = []
	for row in curser:
		data_tuple.append(row)
	print(data_tuple)
	conn.close()
	df = pd.DataFrame(data_tuple, columns= list(dict_col_and_types.keys()))
	print(df)


if __name__ == "__main__":
	db_loc = r'C:\Users\chand\Documents\P\Projects\Locally_personalised_ads\db\payment_db.db'
	if (checking_connection(db_loc)):
		print("database connection successfull")

	table_name = "tab1"
	dict_col_and_types = {"ID" : "INTEGER PRIMARY KEY AUTOINCREMENT",
							"MONTH" : "TEXT NOT NULL",  #can we have seprate columns as years and month
							"FOOD" : "REAL NOT NULL", 
							"FUEL" : "REAL NOT NULL"} 
	#command = create_table_command(table_name, dict_col_and_types)
	#executing_command(command, db_loc)   
	# Table is created when you run the previous line 
	# tab1 is already created
	dict_col_and_values = {"ID" : 1, 
							"MONTH" : '\"2015 - 01\"', 
							"FOOD" : 10000, 
							"FUEL" : 60000}
	command = create_insert_command(table_name, dict_col_and_values)
	#print(command)
	#executing_command(command, db_loc)
	from_csv(db_loc, table_name, dict_col_and_types)
	#selecting_data_for_model(db_loc, table_name, dict_col_and_types)


		#48	2018-12	9200	1250
