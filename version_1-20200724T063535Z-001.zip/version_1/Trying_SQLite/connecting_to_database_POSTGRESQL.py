import psycopg2 as pg_sql
import pandas as pd

def creating_dict_connection_values():
	dict_connection_values = {}
	dict_connection_values["host"] = "localhost" # the host name or ip address
	dict_connection_values["database"] = "payments_db" 
	dict_connection_values["port"] = "5432" 
	dict_connection_values["user"] = "postgres" 
	dict_connection_values["password"]  = "123!@#"
	return (dict_connection_values)

def checking_connection(dict_connection_values):
	#establishing a connection 
	conn = pg_sql.connect(host = dict_connection_values["host"], # the host name or ip address
					database = dict_connection_values["database"], 
					port = dict_connection_values["port"], 
					user = dict_connection_values["user"], 
					password = dict_connection_values["password"])
	conn.close()
	return (True)

def executing_command(command, dict_connection_values):
	# for creating table inserting data this function can be used

	if checking_connection(dict_connection_values):
		conn = pg_sql.connect(host = dict_connection_values["host"], # the host name or ip address
					database = dict_connection_values["database"], 
					port = dict_connection_values["port"], 
					user = dict_connection_values["user"], 
					password = dict_connection_values["password"])
		cursor = conn.cursor()
		cursor.execute(command)
		conn.commit()
		conn.close()


def create_table_command(table_name, dict_col_and_types):
	command = "CREATE TABLE {} ".format(table_name)
	command += "("
	for col in dict_col_and_types.keys():
		command += str(col) + str(" ")
		command += str(dict_col_and_types[col]) + str(" ,")
	command = command[: -1]
	command += ")"
	command += ";"
	return (command)


def create_insert_command(table_name, dict_col_and_values):
	command = "INSERT INTO {} ".format(table_name)
	command += " ("
	for col in dict_col_and_values.keys():
		command += str(col) + str(" ,")
	command = command[: -1]
	command += ") "
	command += "VALUES" 
	command += "("	
	for col in dict_col_and_values.keys():
		command += str(dict_col_and_values[col]) + str(" ,")
	command = command[: -1]
	command += ")"
	command += ";"
	return (command) 


def from_csv(dict_connection_values, table_name, dict_col_and_types):
	command = create_table_command(table_name, dict_col_and_types)
	executing_command(command, dict_connection_values)   
	df = pd.read_csv(r"Book3.csv")
	dict_col_and_values = dict_col_and_types
	for x in df.values:
		e = []
		for t in tuple(x):
			if type(t) is str:
				e.append(str('\'') + str(t) + str('\''))
			else:
				e.append(t) 
		i = 0
		for col in dict_col_and_values.keys():
			dict_col_and_values[col] = e[i]
			i += 1 
		command = create_insert_command(table_name, dict_col_and_values)
		executing_command(command, dict_connection_values)


#record = cursor.fetchall()

if __name__ == "__main__":
	dict_connection_values = creating_dict_connection_values()
	if (checking_connection(dict_connection_values)):
		print("{} Database connection successfull".format(dict_connection_values["database"]))
	

	# creating a table 

	table_name = "tab1"
	dict_col_and_types = {"ID" : "INT PRIMARY KEY NOT NULL",
							"MONTH" : "TEXT NOT NULL",  #can we have seprate columns as years and month
							"FOOD" : "REAL NOT NULL", 
							"FUEL" : "REAL NOT NULL"} 
	command = create_table_command(table_name, dict_col_and_types)
	#executing_command(command, dict_connection_values)	
	#Table is created when you run the previous line 


	# inserting a sample row

	dict_col_and_values = {"ID" : 1, 
							"MONTH" : "\'2015 - 01\'", 
							"FOOD" : 10000, 
							"FUEL" : 60000}
	command = create_insert_command(table_name, dict_col_and_values)

	#executing_command(command, dict_connection_values)
	
	#this will insert the row with specified values into the db, so you go ahead delete that row or the table 
	#itself if u want as we will see next how to get the values from the csv file



	# from csv file go ahead and drop the column in the sql command line
	# as the function itself will crate the table and get the values from the csv file
	
	#from_csv(dict_connection_values, table_name, dict_col_and_types)




